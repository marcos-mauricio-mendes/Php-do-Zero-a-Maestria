<?php

  $str = "este item está em ";
  $promo = "promoção";

  echo ucfirst($str) . strtoupper($promo);