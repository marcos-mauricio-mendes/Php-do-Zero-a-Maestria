<?php

  $palavra = "Testando";

  $palavraInvertida = strrev($palavra);

  echo "$palavra <br>";
  echo "$palavraInvertida <br>";

  $frase = "O programador estava com o prazo curto para fazer o sistema";

  $fraseInvertida = strrev($frase);

  echo "$frase <br>";
  echo "$fraseInvertida <br>";