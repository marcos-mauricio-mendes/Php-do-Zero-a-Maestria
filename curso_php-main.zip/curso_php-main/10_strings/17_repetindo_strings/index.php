<?php

  $str = "Teste";

  $strRepetida = str_repeat($str, 5);

  echo "$strRepetida <br>";

  $frase = "Testando repetição por frase ";

  echo str_repeat($frase, 3);