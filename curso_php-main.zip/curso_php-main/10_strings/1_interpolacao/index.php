<?php

  // O ideal é se manter apenas com uma das sintaxes

  $nome = "Matheus";
  $idade = 29;
  $profissao = "Programador";

  echo "Eu sou o $nome e tenho $idade anos, e atuo como $profissao <br>";

  echo "Eu sou o {$nome} e tenho {$idade} anos, e atuo como {$profissao} <br>";