<?php

  $arr = ["O", "PHP", "é", "muito", "legal"];

  $frase = implode(" ", $arr);

  echo "$frase <br>";