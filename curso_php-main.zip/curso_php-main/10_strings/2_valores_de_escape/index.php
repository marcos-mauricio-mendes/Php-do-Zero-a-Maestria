<?php

  header("Content-type: text/plain");

  // pular linha
  echo "Isso aqui vai ficar na primeira linha \n E isso na segunda linha \n";

  // Tab
  echo "Testando o tab \t aqui \n";

  // Barra invertida
  echo "Barra invertida \\ \n";

  // Dólar
  echo "Imprimindo o dólar \$teste";