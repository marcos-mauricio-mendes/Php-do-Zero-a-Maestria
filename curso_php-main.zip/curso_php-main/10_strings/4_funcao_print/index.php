<?php

  print("Imprimindo algo com print <br>");

  $carro = "BMW";

  print("Aquele carro é da marca $carro <br>");