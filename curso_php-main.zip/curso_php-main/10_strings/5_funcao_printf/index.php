<?php

  $nome = "Matheus";

  // %s -> string

  printf("O nome é %s <br>", $nome);

  // %d -> int

  $n = 10;

  printf("O número é %d e o outro é %d <br>", $n, 150);

  // %f -> float

  printf("A temperatura atual é %.1f <br>", 12.58);