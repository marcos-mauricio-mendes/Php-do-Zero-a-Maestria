<?php

  $str1 = "    Matheus  ";

  echo "Esta é a string 1: $str1. <br>";

  $str1Limpa = trim($str1);

  echo "Esta é a string 1: $str1Limpa. <br>";

  $str1Limpa2 = rtrim($str1);

  echo "Esta é a string 1: $str1Limpa2. <br>";