<?php

  $arr = [];

  // Adicionando valores
  print_r($arr);
  echo "<br>";

  $arr[0] = 10;

  print_r($arr);
  echo "<br>";

  $arr[1] = 15;

  print_r($arr);
  echo "<br>";

  $arr[5] = 25;

  print_r($arr);
  echo "<br>";

  // Modificar valores
  $arr[1] += 55;

  print_r($arr);
  echo "<br>";

  $arrAssoc = [];

  print_r($arrAssoc);
  echo "<br>";

  $arrAssoc["carro"] = "BMW";

  print_r($arrAssoc);
  echo "<br>";

  $arrAssoc["aviao"] = "Boeing";

  print_r($arrAssoc);
  echo "<br>";

  $arrAssoc["carro"] = "Ferrari";

  print_r($arrAssoc);
  echo "<br>";