<?php

  $arr = range(1, 20);

  shuffle($arr);

  print_r($arr);
  echo "<br>";

  shuffle($arr);

  print_r($arr);
  echo "<br>";