<?php

  $arr = [2, 4, 34, 34.1, 324, 12, 34, 1];

  $soma = array_sum($arr);

  print_r($arr);
  echo "<br>";
  echo $soma;