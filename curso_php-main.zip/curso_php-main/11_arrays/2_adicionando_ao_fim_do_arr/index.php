<?php

  $arr = [1, 2, 3];

  $arr[] = 4;

  print_r($arr);
  echo "<br>";

  $arr[] = 5;

  print_r($arr);
  echo "<br>";


  $arr2 = [];

  $arr2[] = 1;

  print_r($arr2);
  echo "<br>";

  $arr3 = [];

  $arr3['teste'] = 'testando';

  print_r($arr3);
  echo "<br>";