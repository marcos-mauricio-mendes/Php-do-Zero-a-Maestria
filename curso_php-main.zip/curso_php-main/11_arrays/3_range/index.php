<?php

  $arr = range(1, 10);

  print_r($arr);
  echo "<br>";

  $arr2 = range(5, 50);

  print_r($arr2);
  echo "<br>";

  $arr3 = range(0, 1000, 100);

  print_r($arr3);
  echo "<br>";