<?php

  $arr = [1, 2, 3];

  echo count($arr) . "<br>";

  $arr2 = range(1, 10);

  echo count($arr2) . "<br>";

  $arr3 = ['nome' => 'Matheus', 'idade' => 29, 'profissao' => 'Programador'];
  
  echo count($arr3) . "<br>";
