<?php

  class User {

  }

  class Programador {

    // propriedades
    // métodos

  }