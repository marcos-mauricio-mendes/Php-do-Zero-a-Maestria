<?php

  class User {

  }

  $matheus = new User;
  $pedro = new User;
  $maria = new User;