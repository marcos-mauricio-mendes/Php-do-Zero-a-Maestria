<?php

  class Car {

  }

  $bmw = new Car;
  $ferrari = new Car;
  $fiat = new Car;