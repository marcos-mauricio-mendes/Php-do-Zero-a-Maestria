<?php

  $d = date('d/m/y'); // day / month / year

  echo $d . "<br>";

  $d2 = date('d, M - Y');

  echo $d2 . "<br>";

  $d3 = date('d/m/Y');

  echo $d3 . "<br>";

  $d4 = date('l, F - Y');

  echo $d4 . "<br>";