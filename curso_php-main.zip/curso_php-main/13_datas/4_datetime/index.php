<?php

  $data = new DateTime();

  print_r($data);
  echo "<br>";
