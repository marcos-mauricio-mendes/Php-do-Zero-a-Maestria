<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="processamento.php" method="GET">
    <div>
      <input type="text" name="nome" placeholder="Preencha seu nome">
    </div>
    <div>
      <input type="text" name="idade" placeholder="Preencha sua idade">
    </div>
    <div>
      <input type="submit" value="Enviar">
    </div>
  </form>
</body>
</html>