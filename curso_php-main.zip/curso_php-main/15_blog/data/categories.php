<?php

  $categories = [
    'PHP',
    'HTML',
    'CSS',
    'JavaScript',
    'Bootstrap',
    'Java',
    'C#'
  ];