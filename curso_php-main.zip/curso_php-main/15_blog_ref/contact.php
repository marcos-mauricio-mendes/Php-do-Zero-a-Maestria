<!-- Helpers -->
<?php
  include_once("helpers/url.php");
?>
<!-- Inclusão do cabeçalho -->
<?php
  include_once("templates/header.php");
?>
  <main>
    <h1>Página de contato</h1>
  </main>
<!-- Inclusão do rodapé -->
<?php
  include_once("templates/footer.php");
?>