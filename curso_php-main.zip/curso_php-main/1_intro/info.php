<?php

  phpinfo();

?>