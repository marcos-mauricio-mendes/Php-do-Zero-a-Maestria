<?php

  echo "Testando o PHP";

?>

Aqui não é PHP