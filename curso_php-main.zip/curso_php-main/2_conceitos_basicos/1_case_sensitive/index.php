<?php

  // Não é case sensitive
  echo "teste <br>";
  eChO "testando 2 <br>";
  ECHO "testando 3 <br>";

  // É case sensitive
  $nome = "Matheus";
  $NOME = "Teste";

  echo $nome;
  echo "<br>";
  echo $NOME;