<?php

  echo "Uma linha <br>";
  echo "Outra de uma linha  <br>";

  if(5 > 2) {
    echo "Dentro do if";
  }