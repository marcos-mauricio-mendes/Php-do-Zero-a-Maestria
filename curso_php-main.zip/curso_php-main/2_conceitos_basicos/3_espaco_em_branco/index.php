<?php

 echo                                 "testando espaço em branco <br>";
 echo "testando espaço <br>"             ;
 echo
 "quebra de linha <br>"
 ;
 echo "quebra de linha <br>"
 ;

 echo "quebra de linha <br>"
 ;

 echo
 "quebra de 
 linha <br>"
 ;