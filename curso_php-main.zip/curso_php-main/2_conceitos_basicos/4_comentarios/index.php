<?php

 // Este é um comentário
 echo "Teste comentário"; // Isso aqui imprime algo na tela

 # Outro tipo de comentário

 /*
  Comentário
  multi
  linha
*/