<?php

  // Esta variável contém o nome da pessoa
  $nome = "Matheus";

  // Esta variável contém a idade da pessoa
  $idade = 29;

  // Esta variável contém a profissão da pessoa
  $profissao = "Programador";

  echo $profissao;