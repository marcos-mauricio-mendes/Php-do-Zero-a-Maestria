<?php

  // function echo() {
  //   return true;
  // }

  // function while() {
  //   return true;
  // }

  function whileNew() {
    return true;
  }