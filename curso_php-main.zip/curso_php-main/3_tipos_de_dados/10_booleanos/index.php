<?php

  echo true;
  echo "<br>";
  echo false;

  if(true) {
    echo "É verdadeiro! <br>";
  }

  if(5 > 2) { // true
    echo "É verdadeiro! <br>";
  }

  $podeEntrar = true;

  if($podeEntrar) {
    echo "O usuário pode entrar";
  }