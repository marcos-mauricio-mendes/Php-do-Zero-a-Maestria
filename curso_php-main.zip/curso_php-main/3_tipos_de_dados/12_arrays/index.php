<?php

  $a = [1, 2, 3];

  print_r($a);
  echo "<br>";
  echo $a[0];

  $arr = ["Matheus", 1005, true];

  echo "<br>";
  print_r($arr);
  echo "<br>";
  print_r($arr[1]);