<?php

  $arr = ['nome' => 'Shark', 'patas' => 4, 'cor' => 'Marrom'];

  echo $arr['nome'];
  echo "<br>";
  print_r($arr);
  echo "<br>";
  echo $arr['patas'];

  $arrAssoc = ['chave' => 'valor', 'bool' => true];

  echo "<br>";
  print_r($arrAssoc);