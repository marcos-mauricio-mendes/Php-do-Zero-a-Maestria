<?php

  echo NULL;

  $nome = NULL;

  if(is_null($nome)) {
    echo "O valor é nulo!";
  }

  $nome = "Matheus";

  if(is_null($nome)) {
    echo "O valor é nulo!";
  }