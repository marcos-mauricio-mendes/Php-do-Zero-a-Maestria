<?php

  echo 5;
  echo "<br>";
  echo 5 + 7;
  echo "<br>";
  echo 7;
  echo "<br>";
  echo -12;
  echo "<br>";
  echo 5 - 12;

  $n = 5;

  echo "<br>";
  echo $n;