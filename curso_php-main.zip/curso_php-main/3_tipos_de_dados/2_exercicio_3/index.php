<?php

  echo 5;
  echo "<br>";
  echo 50;
  echo "<br>";
  echo 5000;

?>