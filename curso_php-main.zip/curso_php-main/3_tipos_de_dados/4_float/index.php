<?php

  $a = 1.12;

  echo $a;
  echo "<br>";
  echo 1.123;
  echo "<br>";
  echo 12.5 + 1.3278;
  echo "<br>";
  echo 12 + 1.3278;