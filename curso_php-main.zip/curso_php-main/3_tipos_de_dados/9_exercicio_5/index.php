<?php

  echo 'Testando aspas simples <br>';
  echo "Teste de aspas duplas <br>";

  $nome = "Matheus";
  $idade = 29;

  echo "Olá, eu sou o $nome e tenho $idade anos";