<?php

  $teste = "Algum texto";

  echo $teste;

  $num = 10;

  echo "<br>";
  echo $num;

  $_nome = "Matheus";

  echo "<br>";
  echo $_nome;

  echo "<br>";

  $velocidadeMaxima = 100;
  $velocidade_minima = 100;