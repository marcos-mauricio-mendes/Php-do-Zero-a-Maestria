<?php

  $velocidade = 100; // int
  $marca = "Ferrari"; // string
  $itens = ["Teto solar", "Motor 2.0", "Porta malas grande", "Piloto automático"]; // array

  echo $velocidade;
  echo "<br>";
  echo $marca;
  echo "<br>";
  print_r($itens);