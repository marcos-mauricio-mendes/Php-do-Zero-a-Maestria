<?php

  $a = 11; // int
  $b = 99.324; // float

  $c = $a + $b;

  echo $c;