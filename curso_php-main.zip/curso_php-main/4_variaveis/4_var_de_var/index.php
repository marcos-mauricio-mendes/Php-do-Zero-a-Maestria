<?php

  $x = "nome"; // valor de nome

  echo "$x <br>";

  $$x = "Matheus"; // var com o nome de x (nome), com valor de Matheus

  echo "$nome <br>";