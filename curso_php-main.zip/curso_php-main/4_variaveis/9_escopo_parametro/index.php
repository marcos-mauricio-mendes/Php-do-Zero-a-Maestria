<?php

  function soma($a, $b) {

    echo $a + $b;
    echo "<br>";

  }

  soma(2, 4);
  soma(6, 8);
  soma(10, 10);