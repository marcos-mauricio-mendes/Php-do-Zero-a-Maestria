<?php

  echo "testando a concatenação";
  echo "<br>";
  echo "testando" . " a " . "concatenação";
  echo "<br>";
  $t = "testando";
  $c = "concatenação";
  echo $t . " a " . $c;

  echo "<br>";
  $marca = "Ferrari";
  $motor = "3.0";
  $vel_max = 200;

  echo "O carro da " . $marca . " tem um motor " . $motor . " e chega uma velocidade de " . $vel_max . "km/h";

  echo "<br>";