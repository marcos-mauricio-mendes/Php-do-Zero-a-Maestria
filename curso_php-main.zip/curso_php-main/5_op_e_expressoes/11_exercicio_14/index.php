<?php

  $saudacao = "Sr.";
  $nome = "Pedro";
  $sobrenome = "Amaral";

  $frase = "O " . $saudacao . " " . $nome . " " . $sobrenome . ", vem hoje para a reunião as 14h";

  echo $frase;