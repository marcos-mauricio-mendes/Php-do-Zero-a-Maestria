<?php

  $x = 0;
  $y = 0;

  $x++;
  $y = $y + 1;

  echo "x: " . $x . "<br>";
  echo "y: " . $y . "<br>";

  $n = 10;
  $m = 10;

  $n--;
  $m = $m - 1;

  echo "n: " . $n . "<br>";
  echo "m: " . $m . "<br>";

