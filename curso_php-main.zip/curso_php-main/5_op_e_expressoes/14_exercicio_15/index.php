<?php

  $a = 4;
  $b = 5;
  $c = 4;

  if($a == $b) {
    echo "A é igual a B <br>";
  }

  if($a == $c) {
    echo "A é igual a C <br>";
  }