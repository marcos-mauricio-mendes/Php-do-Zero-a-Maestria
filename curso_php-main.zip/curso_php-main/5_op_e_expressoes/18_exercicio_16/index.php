<?php

  // ==, !=, ===, !==

  $a = 5;
  $b = 3;

  if($a == $b) {
    echo "A é igual a B <br>";
  }

  if($a != $b) {
    echo "A é diferente a B <br>";
  }

  if($a === $b) {
    echo "A é idêntico a B <br>";
  }

  if($a !== $b) {
    echo "A não é idêntico a B <br>";
  }