<?php

  // comparação 1
  if(12 < 5 || "João" === "João") {
    echo "A operação 1 é verdadeira <br>";
  }
  
  // comparação 2
  if(1 > 5 || 1) {
    echo "A operação 2 é verdadeira <br>";
  }

  // comparação 3
  if(20 === "20" && 51 >= 31) {
    echo "A operação 3 é verdadeira <br>";
  }

  // comparação teste
  if(20 == "20" && 51 >= 31) {
    echo "A operação teste é verdadeira <br>";
  }