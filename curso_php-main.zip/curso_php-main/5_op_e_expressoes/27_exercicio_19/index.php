<?php

  $a = (int) "testando";
  echo $a . "<br>";
  $b = (int) "asd";
  echo $b . "<br>";

  $c = (int) 12.9;
  echo $c . "<br>";
  $d = (int) 5;
  echo $d . "<br>";

  $e = (int) true;
  echo $e . "<br>";
  $f = (int) false;
  echo $f . "<br>";

  $g = (int) [1, 2, 3];
  echo $g . "<br>";
  $h = (int) [1, 2, 3, 4, 5, 6];
  echo $h . "<br>";