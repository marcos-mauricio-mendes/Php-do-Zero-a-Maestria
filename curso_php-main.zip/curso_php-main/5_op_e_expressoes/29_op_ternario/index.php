<?php

  // true
  echo 20 > 10 ? "Deu true <br>" : "Deu false <br>";

  // false
  echo 20 > 50 ? "Deu true <br>" : "Deu false <br>";

  $a = 10;
  $b = 5;

  echo $a >= $b ? "Deu true <br>" : "Deu false <br>";

  echo $a === $b ? "Deu true <br>" : "Deu false <br>";

  echo $a === $b && 10 > 5 ? "Deu true <br>" : "Deu false <br>";