<?php

  // -, /, *
  $a = 10;
  $x = 5;
  $z = 9;

  $operacao = ($x - $z) / $a * $z;

  echo $operacao;