<?php

  $a = 10;
  $b = 5;

  echo $a <= $b ? "A é menor ou igual a B <br>" : "B é menor que A <br>";

  echo $a >= $b ? "A é maior ou igual a B <br>" : "B é maior que A <br>";