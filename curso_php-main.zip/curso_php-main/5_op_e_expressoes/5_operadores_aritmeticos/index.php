<?php

  $soma = 5 + 5;
  echo $soma . "<br>";

  $subtracao = 10 - 2;
  echo $subtracao . "<br>";

  $multi = 2 * 199;
  echo $multi . "<br>";

  $divisao = 123 / 48;
  echo $divisao . "<br>";

  $op = 5 + (2 / 7) * 8;
  echo $op . "<br>";

