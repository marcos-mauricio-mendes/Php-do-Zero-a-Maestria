<?php

  // +, -, /, *
  $a = 3;
  $b = 12;

  $op1 = $a - $b;
  echo $op1;
  echo "<br>";

  $c = 12.4;

  $op2 = $op1 * $c;
  echo $op2;
  echo "<br>";

  $d = 4.8;

  $op3 = $op2 + $d;
  echo $op3;
  echo "<br>";

  $e = 9.2;

  $op4 = $op3 / $e;

  echo $op4;
  echo "<br>";