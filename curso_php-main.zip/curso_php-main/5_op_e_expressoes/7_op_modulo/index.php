<?php

  echo 12 % 2;
  echo " módulo <br>";
  echo 12 / 2;
  echo " divisão <br>";

  echo 13 % 2;
  echo "<br>";
  echo 13 % 5;
  echo "<br>";

  $a = 20;
  $b = 4;
  $c = 12;

  echo $a % $b;
  echo "<br>";
  echo $a % $c;