<?php

  $a = 14;
  $b = 2;
  $c = 3;

  echo $a % $b;
  echo "<br>";
  echo $a % $c;
  echo "<br>";