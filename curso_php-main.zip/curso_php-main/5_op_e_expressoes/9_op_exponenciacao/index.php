<?php

  echo 5 ** 2;
  echo "<br>";
  echo 2 ** 10;
  echo "<br>";

  $a = 7;
  $b = 4;

  echo $a ** $b;
  echo "<br>";

  $c = 12;

  $d = $c ** $a;

  echo $d;