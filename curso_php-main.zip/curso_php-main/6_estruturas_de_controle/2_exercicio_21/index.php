<?php

  $a = 5;
  $b = 2;

  if($a > $b) {

    echo "Entrou no if 1 <br>";

  }

  $nome = "Matheus";
  $nome2 = "Pedro";

  if($nome != $nome2) {

    echo "Entrou no if 2 <br>";

  }

  $x = 12;
  $y = 11;

  if($x <= $y) {

    echo "Entrou no if 3 <br>";

  }