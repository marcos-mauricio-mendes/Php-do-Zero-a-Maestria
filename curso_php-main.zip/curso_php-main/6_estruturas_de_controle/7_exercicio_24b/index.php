<?php

  $peso = 16.12;

  if($peso > 80) {

    echo "O pacote está pesado demais <br>";

  } else {

    echo "Peso dentro do limite <br>";

  }