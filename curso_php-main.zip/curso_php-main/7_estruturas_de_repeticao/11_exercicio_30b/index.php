<?php

  $arr = [];

  for($i = 1; $i <= 10; $i++) {

    array_push($arr, $i);

  }

  print_r($arr);