<?php

  include "teste.php";

?>

<p>Após o include</p>
<p>Imprimindo c <?php echo $c; ?></p>