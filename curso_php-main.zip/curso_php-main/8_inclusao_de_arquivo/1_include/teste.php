<?php

  $c = 5;

?>

<h1>Testando o include</h1>