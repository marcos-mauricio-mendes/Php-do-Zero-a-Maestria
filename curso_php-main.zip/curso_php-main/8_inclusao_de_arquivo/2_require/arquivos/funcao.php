<?php

  $idade = 12;

  echo "A idade é $idade <br>";

  include __DIR__ . "/../testando.php";