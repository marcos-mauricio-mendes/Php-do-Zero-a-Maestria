<p>Testando</p>

<?php

  require "teste.php";

?>

<p>Arquivo do include</p>

<?php

  require "arquivos/funcao.php";

?>