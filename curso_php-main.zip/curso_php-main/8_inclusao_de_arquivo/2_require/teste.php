<div>
  <h1>Encontre os melhores produtos:</h1>
  <p>Caneta BIC R$1,00</p>
</div>