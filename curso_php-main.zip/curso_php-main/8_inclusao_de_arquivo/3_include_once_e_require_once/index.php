<?php

  // Arquivos que não existem
  // include_once "teste.php";

  // Arquivos que existem
  include_once "teste2.php";
  include_once "teste2.php";

  // Arquivo que não existe
  // require_once "teste.php";

  require_once "teste3.php";
  require_once "teste3.php";

?>

<p>Testando código!</p>