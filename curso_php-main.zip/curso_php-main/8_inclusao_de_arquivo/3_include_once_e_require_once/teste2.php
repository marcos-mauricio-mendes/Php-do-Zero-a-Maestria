<?php

  echo "TESTANDO INCLUDE ONCE <br>";