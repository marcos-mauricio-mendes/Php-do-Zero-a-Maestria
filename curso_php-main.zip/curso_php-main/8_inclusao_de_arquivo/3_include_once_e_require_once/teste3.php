<?php

  echo "TESTANDO REQUIRE ONCE <br>";