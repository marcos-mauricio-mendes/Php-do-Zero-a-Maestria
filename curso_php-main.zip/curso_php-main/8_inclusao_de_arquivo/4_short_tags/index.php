<?php

  echo "Testando código PHP nas tags normais <br>";

?>

<?

  echo "Testando as short tags <br>";

?>