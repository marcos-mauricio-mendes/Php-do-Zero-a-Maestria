<?php

  $nome = "Matheus";
  $produtos = ["Carro", "Avião", "Lancha"];

?>