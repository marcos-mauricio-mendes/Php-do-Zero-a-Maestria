<?php

  function numAoQuadrado($x) {

    $resultado = $x ** 2;

    return $resultado;

  }

  echo numAoQuadrado(2) . "<br>";

  $num = numAoQuadrado(4);
  
  echo $num . "<br>";

  $x = numAoQuadrado(123);

  echo $x . "<br>";
