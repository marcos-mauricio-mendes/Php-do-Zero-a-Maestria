<?php

  $arr = [
    "Teste",
    123,
    12393.45843,
    true,
    [1,2,3]
  ];

  print_r($arr);

  echo "<br>";

  var_dump($arr);