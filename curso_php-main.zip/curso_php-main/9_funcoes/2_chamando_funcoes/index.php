<?php

  // definindo funcao
  function soma() {

    $a = 5;
    $b = 4;

    echo $a + $b . "<br>";

  }

  // chamando / invocando funcao
  soma();
  soma();

  // funcao do php
  echo strtoupper("testando função");
