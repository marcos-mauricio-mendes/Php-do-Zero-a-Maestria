<?php

  $arr = ["Teste", "Olá", "Balão", "Janela", "Planta"];

  $teste = implode(", ", $arr);

  echo $teste;