<?php

  // definição
  function multiplicacao() {

    $x = 5;
    $y = 4.12;
    $z = 8;

    $resultado = $x * $y * $z;

    echo $resultado . "<br>";

  }

  // invocação
  multiplicacao();