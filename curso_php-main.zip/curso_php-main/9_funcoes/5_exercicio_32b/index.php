<?php

  function fullName() {

    $firstName = "Matheus";
    $lastName = "Battisti";

    echo $firstName . " " . $lastName;

  }

  fullName();